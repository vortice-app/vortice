# lsd
LSD - line-square-dot: an addicting game

play the game at http://lalo.li/lsd/

and yes, there are some bugs with my homemade physics/collision engine, feel free to send awesome push requests! 

Franz Enzenhofer

** heyho, if you are a native app developer - let's make an official native app out of this, we sell it on the appstore for 0,99c and we make 50/50 - if interrested please mail fe [[@t]] f19n dot com **



Something nearly like MIT License (MIT)

Copyright (c) 2015-9999 Franz Enzenhofer

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software. Also you must attribute 
this repo with every fork (i.e.: with a link or a mention or something like that)

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
