Attribution
===========

Organized by asset:

- `assets/sprites/*` made by `www.kenney.nl`, taken from OpenGameArt.
  License: CC0
- `assets/sounds/happy.*` made by `rezoner`, taken from OpenGameArt.
  License: CC-BY 3.0
- `assets/sounds/air.wav` made by `remaxim`, taken from OpenGameArt.
  License: CC0
- `assets/sounds/water.wav` made by `kurt`, taken from OpenGameArt.
  License: CC-BY 3.0
- `assets/sounds/earth.wav` made by `qubodup`, taken from OpenGameArt.
  License: CC-BY 3.0
- `assets/sounds/fire.wav` made by `p0ss`, taken from OpenGameArt.
  Licenses: CC-BY-SA 3.0, GPL 3.0, GPL 2.0
- `assets/sounds/pickup.wav` made by `p0ss`, taken from OpenGameArt.
  Licenses: CC-BY-SA 3.0, GPL 3.0, GPL 2.0
- `assets/fonts/minecraftia-webfont.*` made by `Andrew Tyler`, from `http://www.andrewtyler.net/`.
  License: "Free for personal use"
