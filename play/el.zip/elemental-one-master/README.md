Elemental One
==============

A simple, first-time platformer game made along the theme of Ludum Dare 28.

Built with the [Phaser](https://github.com/photonstorm/phaser) HTML5 game
framework. See `ATTRIBUTION.md` for the source of some of the assets.
