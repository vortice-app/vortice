# My name is RED
An HTML5 game made during the #EpicGameJam. The main theme was 'RED'.

<a href="http://epicgamejam.com/"><img src="http://epicgamejam.com/sites/all/themes/epicgamejam/build/svg/epicgamejam_logo.svg" /></a>

### Description of the game
You are RED, a strange character who is suffering from alzheimer. He can't remember is name. So your objective is to remind RED what his name is. For that, you have to collect each letter of his name to complete the level by jumping and avoiding spikes. But carefull, if you don't collect all the letters in time, you brain explode; you're dead.

You have to use the arrow keys to control the player (move left, right and jump). Press the enter button to click on the RED button. Or just.. click it with your mouse.. whatever.

### Screenshots
<img src="http://epicgamejam.com/sites/default/files/game-screenshots/g2.PNG" />
<img src="http://epicgamejam.com/sites/default/files/game-screenshots/g3.PNG" />
<img src="http://epicgamejam.com/sites/default/files/game-screenshots/g4.PNG" />

### Play it

You can play the game <a href="https://williamdasilva.fr/jam/index/red">HERE</a>
